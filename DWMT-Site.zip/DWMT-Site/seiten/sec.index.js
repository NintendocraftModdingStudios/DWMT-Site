document.addEventListener('DOMContentLoaded', () => {
    loadWarnungen();
});

function loadWarnungen() {
    fetch('/warnungen')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(warnungen => {
            const warnungenContainer = document.getElementById('warnungen-container');
            warnungenContainer.innerHTML = '';

            warnungen.forEach((warnung, index) => {
                const warnungDiv = document.createElement('div');
                warnungDiv.className = 'warnung';

                const titleDiv = document.createElement('div');
                titleDiv.className = 'warnung-title';
                titleDiv.textContent = warnung.title;

                const iconImg = document.createElement('img');
                iconImg.src = `icons/${warnung.icon}`;
                iconImg.className = 'warnung-icon';

                const descDiv = document.createElement('div');
                descDiv.className = 'warnung-text';
                descDiv.textContent = warnung.desc;

                const warnzeitraumDiv = document.createElement('div');
                warnzeitraumDiv.className = 'warnzeitraum';
                warnzeitraumDiv.textContent = `Warnzeitraum: ${warnung.warnzeitraum}`;
            
                warnungDiv.appendChild(titleDiv);
                warnungDiv.appendChild(iconImg);
                warnungDiv.appendChild(warnzeitraumDiv);
                warnungDiv.appendChild(descDiv);
                

                warnungenContainer.appendChild(warnungDiv);
            });
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
}
