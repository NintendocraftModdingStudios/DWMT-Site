import express from 'express';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());

app.use(express.static(path.join(__dirname, 'seiten')));
app.use('/pictures', express.static(path.join(__dirname, 'seiten', 'pictures')));
app.use('/css', express.static(path.join(__dirname, 'seiten', 'css')));

// Routen für verschiedene Seiten
app.get('/', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'seiten', 'index.html'));
});

// Weitere Routen hier einfügen, wie bereits vorhanden

// Benutzerdaten (Beispiel)
const users = {
    'felix.kunzmann': { password: 'teichgebiet-ag.admin', isAdmin: true },
    'lilly.kunzmann': { password: 'teichgebiet-admin', isAdmin: false },
    'vanessa.gerner': { password: 'teichgebiet1', isAdmin: false },
    'collin.wittmann': {password: 'wittmann2011', isAdmin: false}
};

// Login-Route
app.post('/login', (req, res) => {
    const { username, password, admin } = req.body;

    if (users[username] && users[username].password === password) {
        if (admin === 'on' && users[username].isAdmin) {
            return res.sendFile(path.resolve(__dirname, 'seiten', 'admin.index.html'));
        } else {
            return res.sendFile(path.resolve(__dirname, 'seiten', 'sec.index.html'));
        }
    } else {
        return res.sendFile(path.resolve(__dirname, 'seiten', 'fail.html'));
    }
});

app.get('/login', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'seiten', 'login.html'));
});

// Pfad zur JSON-Datei für Warnungen
const warnungenFilePath = path.join(__dirname, 'seiten', 'warnungen.json');

// GET /warnungen
app.get('/warnungen', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        res.json(JSON.parse(data));
    });
});

// POST /warnungen
app.post('/warnungen', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        const warnungen = JSON.parse(data);
        const newWarnung = req.body;
        warnungen.push(newWarnung);

        fs.writeFile(warnungenFilePath, JSON.stringify(warnungen, null, 2), (err) => {
            if (err) {
                res.status(500).json({ error: 'Fehler beim Speichern der Warnungen' });
                return;
            }
            res.status(201).json(newWarnung);
        });
    });
});

// DELETE /warnungen/:index
app.delete('/warnungen/:index', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        const warnungen = JSON.parse(data);
        const index = parseInt(req.params.index, 10);

        if (index >= 0 && index < warnungen.length) {
            warnungen.splice(index, 1);

            fs.writeFile(warnungenFilePath, JSON.stringify(warnungen, null, 2), (err) => {
                if (err) {
                    res.status(500).json({ error: 'Fehler beim Speichern der Warnungen' });
                    return;
                }
                res.status(204).end();
            });
        } else {
            res.status(404).json({ error: 'Warnung nicht gefunden' });
        }
    });
});

// Pfad zur JSON-Datei für Hochwasserberichte
const hochwasserberichteFilePath = path.join(__dirname, 'seiten', 'hochwasserbericht.json');

// Versuchen, die Hochwasserberichte aus der JSON-Datei zu laden
let hochwasserberichte = [];

try {
    const data = fs.readFileSync(hochwasserberichteFilePath, 'utf8');
    hochwasserberichte = JSON.parse(data);
} catch (err) {
    console.error('Fehler beim Laden der Hochwasserberichte:', err);
}

// POST /hochwasserbericht
app.post('/hochwasserbericht', (req, res) => {
    const neuerBericht = req.body;

    // Überprüfen der Daten
    if (!neuerBericht.title || !neuerBericht.icon || !neuerBericht.desc || !neuerBericht.warnzeitraum) {
        return res.status(400).json({ error: 'Bitte alle Felder ausfüllen' });
    }

    // Überprüfen, ob der Bericht bereits existiert
    const exists = hochwasserberichte.some(bericht => bericht.title === neuerBericht.title && bericht.desc === neuerBericht.desc);
    if (exists) {
        return res.status(400).json({ error: 'Ein Bericht mit diesen Daten existiert bereits' });
    }

    // Hinzufügen zum Array
    hochwasserberichte.push(neuerBericht);

    // Speichern in die JSON-Datei
    fs.writeFile(hochwasserberichteFilePath, JSON.stringify(hochwasserberichte, null, 2), (err) => {
        if (err) {
            console.error('Fehler beim Speichern der Hochwasserberichte:', err);
            res.status(500).json({ error: 'Fehler beim Speichern der Hochwasserberichte' });
            return;
        }
        console.log('Hochwasserbericht erfolgreich gespeichert.');
        res.status(201).json(neuerBericht);
    });
});

// DELETE /hochwasserbericht/:index
app.delete('/hochwasserbericht/:index', (req, res) => {
    const index = req.params.index;
    if (index >= 0 && index < hochwasserberichte.length) {
        hochwasserberichte.splice(index, 1);
        
        // Nach dem Löschen aktualisieren und in die JSON-Datei schreiben
        fs.writeFile(hochwasserberichteFilePath, JSON.stringify(hochwasserberichte, null, 2), (err) => {
            if (err) {
                console.error('Fehler beim Speichern der Hochwasserberichte nach dem Löschen:', err);
                res.status(500).json({ error: 'Fehler beim Speichern der Hochwasserberichte nach dem Löschen' });
                return;
            }
            console.log('Hochwasserbericht erfolgreich gelöscht.');
            res.status(204).send();
        });
    } else {
        res.status(404).json({ error: 'Bericht nicht gefunden' });
    }
});

// GET /hochwasserbericht
app.get('/hochwasserbericht', (req, res) => {
    res.json(hochwasserberichte);
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
